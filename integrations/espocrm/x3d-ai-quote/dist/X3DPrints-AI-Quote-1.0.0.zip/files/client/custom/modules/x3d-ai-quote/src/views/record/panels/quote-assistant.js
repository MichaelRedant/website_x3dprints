define(['views/record/panels/bottom'], (BottomPanelView) => {
    return class extends BottomPanelView {
        templateContent = `
            <div class="x3d-ai-quote-assistant">
                <div class="alert alert-info">
                    <strong>Gecontroleerde conceptofferte.</strong>
                    De aanvraagtekst wordt bij <em>Analyseren</em> naar OpenAI gestuurd zonder API-opslag
                    (<code>store: false</code>). Verwijder persoonsgegevens die niet nodig zijn.
                    Bedragen komen uitsluitend uit de vaste X3DPrints-prijsregels en niets wordt automatisch verzonden.
                </div>

                <div class="form-group">
                    <label for="x3d-ai-source-{{cid}}">Aanvraagtekst</label>
                    <textarea id="x3d-ai-source-{{cid}}" class="form-control" data-field="sourceText" rows="8">{{sourceText}}</textarea>
                </div>

                <div class="form-group">
                    <label for="x3d-ai-corrections-{{cid}}">Aanvullingen of correcties</label>
                    <textarea id="x3d-ai-corrections-{{cid}}" class="form-control" data-field="corrections" rows="3"
                        placeholder="Bijvoorbeeld: 6 stuks, PETG, 83 g en 4,5 printuren per stuk.">{{corrections}}</textarea>
                    <p class="help-block">Gebruik dit veld om ontbrekende slicerdata of afspraken toe te voegen en analyseer opnieuw.</p>
                </div>

                <div class="btn-group" role="group" aria-label="AI-offerteacties">
                    <button type="button" class="btn btn-primary" data-action="analyze" {{#if busy}}disabled{{/if}}>
                        {{#if busy}}Bezig met analyseren...{{else}}Aanvraag analyseren{{/if}}
                    </button>
                    {{#if quote}}
                    <button type="button" class="btn btn-success" data-action="save" {{#unless quote.canSave}}disabled{{/unless}}>
                        Opslaan als concept
                    </button>
                    {{/if}}
                </div>

                {{#if statusMessage}}
                <div class="alert {{statusClass}}" style="margin-top: 12px;">{{statusMessage}}</div>
                {{/if}}

                {{#if quote}}
                <hr>
                <div class="row">
                    <div class="col-md-8">
                        <h4>{{analysis.quoteTitle}}</h4>
                        <p>{{analysis.requestSummary}}</p>
                    </div>
                    <div class="col-md-4 text-right">
                        <div><strong>{{quote.totalExclVatFormatted}} EUR</strong> excl. btw</div>
                        <div>{{quote.totalInclVatFormatted}} EUR incl. btw</div>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-striped table-condensed">
                        <thead>
                            <tr>
                                <th>Offertepost</th>
                                <th>Aantal</th>
                                <th class="text-right">Eenheidsprijs</th>
                                <th class="text-right">Totaal excl. btw</th>
                            </tr>
                        </thead>
                        <tbody>
                            {{#each quote.lineItems}}
                            <tr>
                                <td>
                                    <strong>{{description}}</strong>
                                    {{#if details}}<div class="text-muted small">{{details}}</div>{{/if}}
                                </td>
                                <td>{{quantity}}</td>
                                <td class="text-right">{{unitPriceFormatted}} EUR</td>
                                <td class="text-right">{{totalFormatted}} EUR</td>
                            </tr>
                            {{/each}}
                        </tbody>
                    </table>
                </div>

                {{#if quote.missingInformation.length}}
                <div class="alert alert-warning">
                    <strong>Nog te bevestigen voor een definitieve offerte:</strong>
                    <ul>
                        {{#each quote.missingInformation}}<li>{{this}}</li>{{/each}}
                    </ul>
                </div>
                {{else}}
                <div class="alert alert-success">
                    Alle vereiste prijsgegevens zijn aanwezig. Controleer de berekening en tekst voor verzending.
                </div>
                {{/if}}

                <div class="form-group">
                    <label for="x3d-ai-customer-text-{{cid}}">Voorstel voor de klant</label>
                    <textarea id="x3d-ai-customer-text-{{cid}}" class="form-control" data-field="customerText" rows="14">{{quote.customerText}}</textarea>
                    <p class="help-block">Deze tekst blijft bewerkbaar en wordt alleen in het concept opgeslagen.</p>
                </div>
                {{/if}}

                {{#if savedRecord}}
                <div class="alert alert-success">
                    Concept opgeslagen: <a href="#X3dAiQuote/view/{{savedRecord.id}}">{{savedRecord.name}}</a>.
                    Er is geen e-mail verstuurd.
                </div>
                {{/if}}
            </div>
        `

        events = {
            'click [data-action="analyze"]': 'actionAnalyze',
            'click [data-action="save"]': 'actionSave',
            'input [data-field="sourceText"]': 'captureSourceText',
            'input [data-field="corrections"]': 'captureCorrections',
            'input [data-field="customerText"]': 'captureCustomerText',
        }

        setup() {
            super.setup();

            this.scope = this.model.entityType || this.model.name || 'Lead';
            this.sourceText = this.buildInitialSourceText();
            this.corrections = '';
            this.result = null;
            this.savedRecord = null;
            this.busy = false;
            this.statusMessage = '';
            this.statusClass = 'alert-info';
        }

        data() {
            const analysis = this.result ? this.result.analysis : null;
            const quote = this.result ? this.prepareQuote(this.result.quote) : null;

            return {
                cid: this.cid,
                sourceText: this.sourceText,
                corrections: this.corrections,
                analysis,
                quote,
                busy: this.busy,
                statusMessage: this.statusMessage,
                statusClass: this.statusClass,
                savedRecord: this.savedRecord,
            };
        }

        buildInitialSourceText() {
            const parts = [];
            const recordName = this.model.get('name');
            const description = this.model.get('description');
            const importSummary = this.model.get('summary');
            const parsedPayload = this.model.get('parsedPayload');

            if (recordName) {
                parts.push(`Onderwerp: ${recordName}`);
            }
            if (description) {
                parts.push(`Aanvraag:\n${description}`);
            }
            if (importSummary) {
                parts.push(`X3DImport-samenvatting:\n${importSummary}`);
            }
            if (parsedPayload) {
                parts.push(`X3DImport-data:\n${parsedPayload}`);
            }

            return parts.join('\n\n');
        }

        captureSourceText(event) {
            this.sourceText = event.currentTarget.value;
        }

        captureCorrections(event) {
            this.corrections = event.currentTarget.value;
        }

        captureCustomerText(event) {
            if (this.result) {
                this.result.quote.customerText = event.currentTarget.value;
            }
        }

        async actionAnalyze() {
            this.captureCurrentValues();
            this.busy = true;
            this.savedRecord = null;
            this.statusMessage = 'De aanvraag wordt gestructureerd en daarna met vaste prijsregels berekend.';
            this.statusClass = 'alert-info';
            await this.reRender();

            try {
                this.result = await Espo.Ajax.postRequest('X3dAiQuote/analyze', {
                    sourceText: this.sourceText,
                    corrections: this.corrections,
                    sourceRecordType: this.scope,
                    sourceRecordId: this.model.id,
                }, {timeout: 120000});
                this.statusMessage = this.result.quote.readyForReview
                    ? 'Analyse gereed. Controleer prijsregels en klanttekst.'
                    : 'Concept gemaakt. Vul de gemarkeerde gegevens aan en analyseer opnieuw.';
                this.statusClass = this.result.quote.readyForReview ? 'alert-success' : 'alert-warning';
            } catch (xhr) {
                this.statusMessage = this.readError(xhr);
                this.statusClass = 'alert-danger';
            } finally {
                this.busy = false;
                await this.reRender();
            }
        }

        async actionSave() {
            if (!this.result || !this.result.quote.canSave) {
                return;
            }

            this.captureCurrentValues();
            this.busy = true;
            this.statusMessage = 'Concept wordt gekoppeld aan dit CRM-record.';
            this.statusClass = 'alert-info';
            await this.reRender();

            try {
                const payload = this.buildSavePayload();
                const record = await Espo.Ajax.postRequest('X3dAiQuote', payload);
                this.savedRecord = {id: record.id, name: record.name || payload.name};
                this.statusMessage = 'Offerteconcept opgeslagen. Er is niets naar de klant verzonden.';
                this.statusClass = 'alert-success';
            } catch (xhr) {
                this.statusMessage = this.readError(xhr);
                this.statusClass = 'alert-danger';
            } finally {
                this.busy = false;
                await this.reRender();
            }
        }

        captureCurrentValues() {
            const source = this.$el.find('[data-field="sourceText"]');
            const corrections = this.$el.find('[data-field="corrections"]');
            const customerText = this.$el.find('[data-field="customerText"]');

            if (source.length) this.sourceText = source.val();
            if (corrections.length) this.corrections = corrections.val();
            if (customerText.length && this.result) this.result.quote.customerText = customerText.val();
        }

        buildSavePayload() {
            const {analysis, quote, ai} = this.result;
            const validUntil = new Date();
            validUntil.setDate(validUntil.getDate() + 30);

            const payload = {
                name: analysis.quoteTitle || `Conceptofferte ${this.model.get('name') || ''}`.trim(),
                status: 'Draft',
                sourceRecordType: this.scope,
                sourceRecordId: this.model.id,
                sourceRecordName: this.model.get('name') || '',
                sourceType: this.scope === 'X3dImport' ? 'X3DImport' : analysis.sourceType,
                requestSummary: analysis.requestSummary,
                sourceText: this.sourceText,
                lineItemsText: JSON.stringify(quote.lineItems, null, 2),
                assumptions: (analysis.assumptions || []).join('\n'),
                missingInformation: (quote.missingInformation || []).join('\n'),
                customerText: quote.customerText,
                currency: quote.currency,
                totalExclVat: quote.totalExclVat,
                vatRate: quote.vatRate,
                vatAmount: quote.vatAmount,
                totalInclVat: quote.totalInclVat,
                validUntil: validUntil.toISOString().slice(0, 10),
                priceRulesVersion: quote.rulesVersion,
                aiModel: ai.model,
                aiResponseId: ai.responseId,
                promptVersion: ai.promptVersion,
            };

            if (this.scope === 'Lead') {
                payload.leadId = this.model.id;
                payload.leadName = this.model.get('name') || '';
            }
            if (this.scope === 'Opportunity') {
                payload.opportunityId = this.model.id;
                payload.opportunityName = this.model.get('name') || '';
            }
            if (this.scope === 'X3dImport') {
                payload.x3dImportId = this.model.id;
                payload.x3dImportName = this.model.get('name') || '';
            }

            const assignedUserId = this.model.get('assignedUserId');
            if (assignedUserId) {
                payload.assignedUserId = assignedUserId;
                payload.assignedUserName = this.model.get('assignedUserName') || '';
            }

            return payload;
        }

        prepareQuote(quote) {
            return {
                ...quote,
                totalExclVatFormatted: this.formatMoney(quote.totalExclVat),
                totalInclVatFormatted: this.formatMoney(quote.totalInclVat),
                lineItems: (quote.lineItems || []).map(item => ({
                    ...item,
                    unitPriceFormatted: this.formatMoney(item.unitPrice),
                    totalFormatted: this.formatMoney(item.total),
                })),
            };
        }

        formatMoney(value) {
            return Number(value || 0).toLocaleString('nl-BE', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
            });
        }

        readError(xhr) {
            return xhr && xhr.responseJSON && xhr.responseJSON.message
                ? xhr.responseJSON.message
                : 'De actie is mislukt. Controleer de serverconfiguratie en probeer opnieuw.';
        }
    }
});
