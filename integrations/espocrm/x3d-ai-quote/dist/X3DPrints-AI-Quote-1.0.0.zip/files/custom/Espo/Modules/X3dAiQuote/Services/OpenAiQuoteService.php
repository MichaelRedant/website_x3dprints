<?php

declare(strict_types=1);

namespace Espo\Modules\X3dAiQuote\Services;

use Espo\Core\Utils\Config;
use RuntimeException;

class OpenAiQuoteService
{
    private const API_URL = 'https://api.openai.com/v1/responses';

    public function __construct(private Config $config)
    {}

    /**
     * @return array{analysis: array<string, mixed>, responseId: string, model: string}
     */
    public function analyze(string $sourceText, string $corrections = ''): array
    {
        $model = (string) ($this->config->get('x3dOpenAiModel') ?: 'gpt-5.4-mini');
        $payload = [
            'model' => $model,
            'store' => false,
            'max_output_tokens' => 3000,
            'instructions' => $this->instructions(),
            'input' => $this->buildInput($sourceText, $corrections),
            'text' => [
                'format' => [
                    'type' => 'json_schema',
                    'name' => 'x3d_quote_analysis',
                    'strict' => true,
                    'schema' => $this->schema(),
                ],
                'verbosity' => 'low',
            ],
        ];

        $response = $this->request($payload);
        $jsonText = $this->extractOutputText($response);
        $analysis = json_decode($jsonText, true, 64, JSON_THROW_ON_ERROR);

        if (!is_array($analysis)) {
            throw new RuntimeException('OpenAI gaf geen bruikbare offerteanalyse terug.');
        }

        return [
            'analysis' => $analysis,
            'responseId' => (string) ($response['id'] ?? ''),
            'model' => (string) ($response['model'] ?? $model),
        ];
    }

    private function resolveApiKey(): string
    {
        $key = trim((string) ($this->config->get('x3dOpenAiApiKey') ?: getenv('OPENAI_API_KEY')));

        if ($key === '') {
            $localConfig = dirname(__DIR__, 5) . '/data/x3d-ai-quote.php';
            if (is_file($localConfig)) {
                $values = require $localConfig;
                if (is_array($values)) {
                    $key = trim((string) ($values['openaiApiKey'] ?? ''));
                }
            }
        }

        if ($key === '') {
            throw new RuntimeException(
                'OPENAI_API_KEY ontbreekt. Configureer de sleutel server-side; zet hem nooit in JavaScript.'
            );
        }

        return $key;
    }

    private function buildInput(string $sourceText, string $corrections): string
    {
        $input = "AANVRAAG:\n" . trim($sourceText);
        if (trim($corrections) !== '') {
            $input .= "\n\nAANVULLINGEN VAN DE MEDEWERKER:\n" . trim($corrections);
        }

        return $input;
    }

    private function instructions(): string
    {
        return <<<'PROMPT'
Je bent de interne offerte-assistent van X3DPrints, een eenpersoons 3D-printatelier in Herzele, België.

Je taak is uitsluitend het structureren van een bestaande klantaanvraag. Je berekent nooit prijzen en verzint nooit ontbrekende maten, printuren, gewichten, aantallen, materiaalkeuzes, kortingen of extra kosten. De server berekent bedragen achteraf met vaste prijsregels.

Regels:
- Schrijf zakelijk, vriendelijk en nuchter. Vermijd overdreven verkooptaal.
- Gebruik alleen informatie uit de aanvraag en expliciete aanvullingen.
- Kies voor materiaal uitsluitend een waarde uit de toegestane materiaallijst.
- Zet onbekende numerieke waarden op null en voeg een concrete vraag toe aan missingInformation.
- Voeg een korting of extra kost alleen toe wanneer die expliciet in de invoer staat.
- 3D-modelleren kost per uur, maar jij geeft alleen het expliciet genoemde of betrouwbaar afleidbare aantal uren terug. Anders null.
- 3D-scannen is een eenmalige offertepost. De klant ontvangt ook het digitale 3D-scanbestand.
- Voor objectscans brengt de klant het fysieke object naar Herzele. Een foto dient alleen voor een eerste haalbaarheidscontrole. Alleen event-scan gebeurt op locatie.
- Een printopdracht is pas volledig prijsbaar met materiaal, aantal, filamentgewicht per stuk en printtijd per stuk.
- sourceType is WebsiteForm bij een herkenbaar websiteformulier, X3DImport bij expliciete X3DImport-context, Email bij gewone e-mail en Manual in alle andere gevallen.
- customerIntroduction en customerClosing bevatten geen bedragen en geen harde leverbelofte.

Toegestane materialen:
PLA_BASIC, PLA_BASIC_GRADIENT, PLA_MATTE, PLA_GLOW, PLA_MARBLE, PLA_SPARKLE, PLA_METAL, PLA_GALAXY, PLA_AERO, PLA_SILK_PLUS, PLA_SILK_MULTI_COLOR, PLA_CF, PLA_WOOD, PLA_TRANSLUCENT, PLA_TOUGH_PLUS, PETG, PC, PC_FR, TPU.

Toegestane scantypes:
small-object, medium-object, large-object, technical-object, event-scan, person-bust, full-body.
PROMPT;
    }

    /** @return array<string, mixed> */
    private function schema(): array
    {
        $nullableString = ['type' => ['string', 'null']];
        $nullableNumber = ['type' => ['number', 'null']];
        $nullableInteger = ['type' => ['integer', 'null']];

        return [
            'type' => 'object',
            'additionalProperties' => false,
            'properties' => [
                'quoteTitle' => ['type' => 'string'],
                'requestSummary' => ['type' => 'string'],
                'customerName' => $nullableString,
                'language' => ['type' => 'string', 'enum' => ['nl', 'en', 'fr', 'de']],
                'sourceType' => [
                    'type' => 'string',
                    'enum' => ['WebsiteForm', 'Email', 'X3DImport', 'Manual'],
                ],
                'printing' => [
                    'type' => 'array',
                    'items' => [
                        'type' => 'object',
                        'additionalProperties' => false,
                        'properties' => [
                            'description' => ['type' => 'string'],
                            'material' => array_merge($nullableString, [
                                'enum' => [
                                    'PLA_BASIC', 'PLA_BASIC_GRADIENT', 'PLA_MATTE', 'PLA_GLOW',
                                    'PLA_MARBLE', 'PLA_SPARKLE', 'PLA_METAL', 'PLA_GALAXY',
                                    'PLA_AERO', 'PLA_SILK_PLUS', 'PLA_SILK_MULTI_COLOR', 'PLA_CF',
                                    'PLA_WOOD', 'PLA_TRANSLUCENT', 'PLA_TOUGH_PLUS', 'PETG',
                                    'PC', 'PC_FR', 'TPU', null,
                                ],
                            ]),
                            'quantity' => $nullableInteger,
                            'weightGramsPerUnit' => $nullableNumber,
                            'printHoursPerUnit' => $nullableNumber,
                            'quality' => [
                                'type' => ['string', 'null'],
                                'enum' => ['standard', 'fine', 'ultra', null],
                            ],
                        ],
                        'required' => [
                            'description', 'material', 'quantity', 'weightGramsPerUnit',
                            'printHoursPerUnit', 'quality',
                        ],
                    ],
                ],
                'scanType' => [
                    'type' => ['string', 'null'],
                    'enum' => [
                        'small-object', 'medium-object', 'large-object', 'technical-object',
                        'event-scan', 'person-bust', 'full-body', null,
                    ],
                ],
                'modelingHours' => $nullableNumber,
                'delivery' => [
                    'type' => ['string', 'null'],
                    'enum' => ['pickup', 'post', '24h', '48h', null],
                ],
                'discountPercent' => $nullableNumber,
                'extraCost' => $nullableNumber,
                'assumptions' => ['type' => 'array', 'items' => ['type' => 'string']],
                'missingInformation' => ['type' => 'array', 'items' => ['type' => 'string']],
                'customerIntroduction' => ['type' => 'string'],
                'customerClosing' => ['type' => 'string'],
            ],
            'required' => [
                'quoteTitle', 'requestSummary', 'customerName', 'language', 'sourceType',
                'printing', 'scanType', 'modelingHours', 'delivery', 'discountPercent',
                'extraCost', 'assumptions', 'missingInformation', 'customerIntroduction',
                'customerClosing',
            ],
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function request(array $payload): array
    {
        if (!function_exists('curl_init')) {
            throw new RuntimeException('De PHP cURL-extensie is niet beschikbaar op de CRM-server.');
        }

        $handle = curl_init(self::API_URL);
        if ($handle === false) {
            throw new RuntimeException('OpenAI-verbinding kon niet worden gestart.');
        }

        // Resolve the secret inside this stack frame so PHP traces never print it as an argument.
        $authorizationHeader = 'Authorization: Bearer ' . $this->resolveApiKey();

        curl_setopt_array($handle, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => 90,
            CURLOPT_HTTPHEADER => [
                $authorizationHeader,
                'Content-Type: application/json',
            ],
            CURLOPT_POSTFIELDS => json_encode($payload, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
        ]);

        $body = curl_exec($handle);
        $status = (int) curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
        $transportError = curl_error($handle);
        curl_close($handle);

        if (!is_string($body)) {
            throw new RuntimeException('OpenAI is niet bereikbaar: ' . $transportError);
        }

        $decoded = json_decode($body, true);
        if ($status < 200 || $status >= 300 || !is_array($decoded)) {
            $message = is_array($decoded)
                ? (string) ($decoded['error']['message'] ?? 'onbekende API-fout')
                : 'ongeldig antwoord';
            throw new RuntimeException(sprintf('OpenAI-aanvraag mislukt (%d): %s', $status, $message));
        }

        return $decoded;
    }

    /** @param array<string, mixed> $response */
    private function extractOutputText(array $response): string
    {
        if (is_string($response['output_text'] ?? null) && trim($response['output_text']) !== '') {
            return $response['output_text'];
        }

        foreach (($response['output'] ?? []) as $output) {
            if (!is_array($output) || ($output['type'] ?? null) !== 'message') {
                continue;
            }
            foreach (($output['content'] ?? []) as $content) {
                if (is_array($content) && ($content['type'] ?? null) === 'output_text') {
                    return (string) ($content['text'] ?? '');
                }
                if (is_array($content) && ($content['type'] ?? null) === 'refusal') {
                    throw new RuntimeException('OpenAI weigerde deze aanvraag te verwerken.');
                }
            }
        }

        throw new RuntimeException('OpenAI gaf geen tekstuitvoer terug.');
    }
}
