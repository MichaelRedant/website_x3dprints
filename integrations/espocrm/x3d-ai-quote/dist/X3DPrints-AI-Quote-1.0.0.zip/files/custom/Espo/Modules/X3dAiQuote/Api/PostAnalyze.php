<?php

declare(strict_types=1);

namespace Espo\Modules\X3dAiQuote\Api;

use Espo\Core\Api\Action;
use Espo\Core\Api\Request;
use Espo\Core\Api\Response;
use Espo\Core\Api\ResponseComposer;
use Espo\Core\Acl;
use Espo\Core\Acl\Table;
use Espo\Core\Exceptions\BadRequest;
use Espo\Core\Exceptions\Forbidden;
use Espo\Core\Exceptions\NotFound;
use Espo\Modules\X3dAiQuote\Services\OpenAiQuoteService;
use Espo\Modules\X3dAiQuote\Services\PricingService;
use Espo\ORM\EntityManager;

class PostAnalyze implements Action
{
    public function __construct(
        private OpenAiQuoteService $openAiQuoteService,
        private PricingService $pricingService,
        private EntityManager $entityManager,
        private Acl $acl,
    ) {}

    public function process(Request $request): Response
    {
        $body = $request->getParsedBody();
        $sourceText = trim((string) ($body->sourceText ?? ''));
        $corrections = trim((string) ($body->corrections ?? ''));
        $sourceRecordType = trim((string) ($body->sourceRecordType ?? ''));
        $sourceRecordId = trim((string) ($body->sourceRecordId ?? ''));

        if ($sourceText === '') {
            throw new BadRequest('Aanvraagtekst ontbreekt.');
        }
        if (mb_strlen($sourceText) > 20000) {
            throw new BadRequest('Aanvraagtekst is langer dan 20.000 tekens.');
        }
        if (mb_strlen($corrections) > 4000) {
            throw new BadRequest('Aanvullingen zijn langer dan 4.000 tekens.');
        }

        $this->assertSourceRecordAccess($sourceRecordType, $sourceRecordId);

        $ai = $this->openAiQuoteService->analyze($sourceText, $corrections);
        $quote = $this->pricingService->calculate($ai['analysis']);
        $quote['customerText'] = $this->composeCustomerText($ai['analysis'], $quote);

        return ResponseComposer::json([
            'analysis' => $ai['analysis'],
            'quote' => $quote,
            'ai' => [
                'responseId' => $ai['responseId'],
                'model' => $ai['model'],
                'promptVersion' => 'x3d-quote-prompt-2026-08-30',
                'storedByOpenAi' => false,
            ],
        ]);
    }

    private function assertSourceRecordAccess(string $entityType, string $id): void
    {
        if (!in_array($entityType, ['Lead', 'Opportunity', 'X3dImport'], true) || $id === '') {
            throw new BadRequest('Een geldig gekoppeld CRM-record is verplicht.');
        }

        $entity = $this->entityManager->getEntityById($entityType, $id);
        if ($entity === null) {
            throw new NotFound('Het gekoppelde CRM-record bestaat niet.');
        }

        if (!$this->acl->check($entity, Table::ACTION_EDIT)) {
            throw new Forbidden('Geen bewerktoegang tot het gekoppelde CRM-record.');
        }
    }

    /**
     * @param array<string, mixed> $analysis
     * @param array<string, mixed> $quote
     */
    private function composeCustomerText(array $analysis, array $quote): string
    {
        $lines = [trim((string) ($analysis['customerIntroduction'] ?? 'Bedankt voor je aanvraag.'))];
        $lines[] = '';
        $lines[] = 'Voorstel:';

        foreach (($quote['lineItems'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }
            $lines[] = sprintf(
                '- %s: %s EUR excl. btw%s',
                (string) ($item['description'] ?? 'Offertepost'),
                number_format((float) ($item['total'] ?? 0), 2, ',', '.'),
                trim((string) ($item['details'] ?? '')) !== '' ? ' (' . trim((string) $item['details']) . ')' : ''
            );
        }

        $lines[] = '';
        $lines[] = 'Totaal excl. btw: ' . number_format((float) $quote['totalExclVat'], 2, ',', '.') . ' EUR';
        $lines[] = 'Btw 21%: ' . number_format((float) $quote['vatAmount'], 2, ',', '.') . ' EUR';
        $lines[] = 'Totaal incl. btw: ' . number_format((float) $quote['totalInclVat'], 2, ',', '.') . ' EUR';

        $missing = $quote['missingInformation'] ?? [];
        if (is_array($missing) && $missing !== []) {
            $lines[] = '';
            $lines[] = 'Nog te bevestigen:';
            foreach ($missing as $item) {
                $lines[] = '- ' . (string) $item;
            }
        }

        $assumptions = $analysis['assumptions'] ?? [];
        if (is_array($assumptions) && $assumptions !== []) {
            $lines[] = '';
            $lines[] = 'Aannames en voorwaarden:';
            foreach ($assumptions as $item) {
                $lines[] = '- ' . (string) $item;
            }
        }

        $lines[] = '';
        $lines[] = trim((string) ($analysis['customerClosing'] ?? 'Na jouw bevestiging controleer ik planning en uitvoerbaarheid.'));
        $lines[] = '';
        $lines[] = 'Dit is een conceptofferte en wordt pas definitief na technische controle door X3DPrints.';

        return implode("\n", $lines);
    }
}
