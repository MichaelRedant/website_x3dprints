<?php

declare(strict_types=1);

namespace Espo\Modules\X3dAiQuote\Services;

use InvalidArgumentException;

class PricingService
{
    public const RULES_VERSION = 'x3d-pricing-2026-08-30';

    private const MATERIAL_PRICE_PER_KG = [
        'PLA_BASIC' => 23.38,
        'PLA_BASIC_GRADIENT' => 33.54,
        'PLA_MATTE' => 23.38,
        'PLA_GLOW' => 33.54,
        'PLA_MARBLE' => 33.54,
        'PLA_SPARKLE' => 33.54,
        'PLA_METAL' => 33.54,
        'PLA_GALAXY' => 32.52,
        'PLA_AERO' => 23.38,
        'PLA_SILK_PLUS' => 33.54,
        'PLA_SILK_MULTI_COLOR' => 33.54,
        'PLA_CF' => 39.64,
        'PLA_WOOD' => 28.46,
        'PLA_TRANSLUCENT' => 23.38,
        'PLA_TOUGH_PLUS' => 23.38,
        'PETG' => 23.38,
        'PC' => 42.99,
        'PC_FR' => 56.99,
        'TPU' => 25.50,
    ];

    private const QUALITY_MULTIPLIER = [
        'standard' => 1.00,
        'fine' => 1.15,
        'ultra' => 1.25,
    ];

    private const SCAN_PRICES = [
        'small-object' => ['label' => '3D-scan klein object', 'price' => 45.00],
        'medium-object' => ['label' => '3D-scan middelgroot object', 'price' => 75.00],
        'large-object' => ['label' => '3D-scan groot object', 'price' => 125.00],
        'technical-object' => ['label' => '3D-scan technisch object', 'price' => 95.00],
        'event-scan' => ['label' => '3D-scannen op beurs of event', 'price' => 225.00],
        'person-bust' => ['label' => '3D-scan buste', 'price' => 95.00],
        'full-body' => ['label' => '3D-scan full body', 'price' => 250.00],
    ];

    private const DRYING_MATERIALS = ['TPU', 'PLA_WOOD', 'PETG', 'PC', 'PC_FR'];
    private const MATERIAL_MARKUP = 0.20;
    private const PROFIT_FACTOR = 3.00;
    private const ELECTRICITY_PER_KWH = 0.23;
    private const PRINTER_POWER_KW = 1.00;
    private const MODELING_RATE_PER_HOUR = 45.00;
    private const VAT_RATE = 21.00;

    /**
     * @param array<string, mixed> $analysis
     * @return array<string, mixed>
     */
    public function calculate(array $analysis): array
    {
        $lineItems = [];
        $missing = $this->stringList($analysis['missingInformation'] ?? []);
        $printing = is_array($analysis['printing'] ?? null) ? $analysis['printing'] : [];

        foreach ($printing as $index => $item) {
            if (!is_array($item)) {
                continue;
            }

            $description = trim((string) ($item['description'] ?? '3D-printwerk'));
            $material = $this->nullableString($item['material'] ?? null);
            $quality = $this->nullableString($item['quality'] ?? null) ?? 'standard';
            $quantity = $this->nullablePositiveInt($item['quantity'] ?? null);
            $weight = $this->nullablePositiveFloat($item['weightGramsPerUnit'] ?? null);
            $hours = $this->nullablePositiveFloat($item['printHoursPerUnit'] ?? null);
            $label = sprintf('Printregel %d (%s)', $index + 1, $description);

            if ($material === null || !isset(self::MATERIAL_PRICE_PER_KG[$material])) {
                $missing[] = $label . ': geldig materiaal ontbreekt.';
            }
            if ($quantity === null) {
                $missing[] = $label . ': aantal ontbreekt.';
            }
            if ($weight === null) {
                $missing[] = $label . ': filamentgewicht per stuk ontbreekt.';
            }
            if ($hours === null) {
                $missing[] = $label . ': printtijd per stuk ontbreekt.';
            }
            if (!isset(self::QUALITY_MULTIPLIER[$quality])) {
                $missing[] = $label . ': kwaliteitsniveau is ongeldig.';
            }

            if (
                $material === null ||
                !isset(self::MATERIAL_PRICE_PER_KG[$material]) ||
                $quantity === null ||
                $weight === null ||
                $hours === null ||
                !isset(self::QUALITY_MULTIPLIER[$quality])
            ) {
                continue;
            }

            $materialCost = ($weight / 1000) * self::MATERIAL_PRICE_PER_KG[$material];
            $materialWithMarkup = $materialCost * (1 + self::MATERIAL_MARKUP);
            $effectiveHours = $hours * self::QUALITY_MULTIPLIER[$quality];
            $electricity = $effectiveHours * self::PRINTER_POWER_KW * self::ELECTRICITY_PER_KWH;
            $unitPrice = ($materialWithMarkup + $electricity) * self::PROFIT_FACTOR;
            $lineTotal = $unitPrice * $quantity;

            $lineItems[] = [
                'type' => 'printing',
                'description' => $description,
                'quantity' => $quantity,
                'unitPrice' => $this->round($unitPrice),
                'total' => $this->round($lineTotal),
                'details' => sprintf(
                    '%s, %s kwaliteit, %.0f g en %.2f uur per stuk',
                    $material,
                    $quality,
                    $weight,
                    $hours
                ),
            ];

            if (in_array($material, self::DRYING_MATERIALS, true)) {
                $dryingTotal = 5.00 + (0.05 * $quantity);
                $lineItems[] = [
                    'type' => 'drying',
                    'description' => 'Filament drogen',
                    'quantity' => 1,
                    'unitPrice' => $this->round($dryingTotal),
                    'total' => $this->round($dryingTotal),
                    'details' => 'Eenmalige voorbereiding binnen deze offerte.',
                ];
            }
        }

        $scanType = $this->nullableString($analysis['scanType'] ?? null);
        if ($scanType !== null) {
            if (!isset(self::SCAN_PRICES[$scanType])) {
                $missing[] = 'Het herkende type 3D-scan is ongeldig.';
            } else {
                $scan = self::SCAN_PRICES[$scanType];
                $lineItems[] = [
                    'type' => 'scanning',
                    'description' => $scan['label'],
                    'quantity' => 1,
                    'unitPrice' => $scan['price'],
                    'total' => $scan['price'],
                    'details' => 'Eenmalige kost. De klant ontvangt ook het digitale 3D-scanbestand.',
                ];
            }
        }

        $modelingHours = $this->nullablePositiveFloat($analysis['modelingHours'] ?? null);
        if ($modelingHours !== null) {
            $modelingTotal = $modelingHours * self::MODELING_RATE_PER_HOUR;
            $lineItems[] = [
                'type' => 'modeling',
                'description' => '3D-modelleren',
                'quantity' => $modelingHours,
                'unitPrice' => self::MODELING_RATE_PER_HOUR,
                'total' => $this->round($modelingTotal),
                'details' => 'Eenmalige kost binnen deze offerte.',
            ];
        }

        $subtotalBeforeDelivery = array_reduce(
            $lineItems,
            static fn (float $sum, array $item): float => $sum + (float) $item['total'],
            0.0
        );

        $extraCost = max(0.0, (float) ($analysis['extraCost'] ?? 0));
        if ($extraCost > 0) {
            $lineItems[] = [
                'type' => 'extra',
                'description' => 'Expliciet vermelde extra kost',
                'quantity' => 1,
                'unitPrice' => $this->round($extraCost),
                'total' => $this->round($extraCost),
                'details' => 'Controleer deze post voor verzending.',
            ];
            $subtotalBeforeDelivery += $extraCost;
        }

        $delivery = $this->nullableString($analysis['delivery'] ?? null) ?? 'pickup';
        $deliveryCost = $this->deliveryCost($delivery, $subtotalBeforeDelivery);
        if ($deliveryCost > 0) {
            $lineItems[] = [
                'type' => 'delivery',
                'description' => $this->deliveryLabel($delivery),
                'quantity' => 1,
                'unitPrice' => $this->round($deliveryCost),
                'total' => $this->round($deliveryCost),
                'details' => '',
            ];
        }

        $subtotalBeforeDiscount = $subtotalBeforeDelivery + $deliveryCost;
        $discountPercent = min(100.0, max(0.0, (float) ($analysis['discountPercent'] ?? 0)));
        $discountValue = $subtotalBeforeDiscount * ($discountPercent / 100);
        if ($discountValue > 0) {
            $lineItems[] = [
                'type' => 'discount',
                'description' => sprintf('Korting %.2f%%', $discountPercent),
                'quantity' => 1,
                'unitPrice' => -$this->round($discountValue),
                'total' => -$this->round($discountValue),
                'details' => 'Alleen toegepast omdat de aanvraag dit expliciet vermeldt.',
            ];
        }

        $totalExclVat = max(0.0, $subtotalBeforeDiscount - $discountValue);
        $vatAmount = $totalExclVat * (self::VAT_RATE / 100);
        $totalInclVat = $totalExclVat + $vatAmount;
        $missing = array_values(array_unique(array_filter(array_map('trim', $missing))));

        if ($lineItems === [] && $missing === []) {
            $missing[] = 'Geen prijsbare 3D-print-, scan- of modelleerdienst herkend.';
        }

        return [
            'rulesVersion' => self::RULES_VERSION,
            'currency' => 'EUR',
            'vatRate' => self::VAT_RATE,
            'lineItems' => $lineItems,
            'subtotalBeforeDelivery' => $this->round($subtotalBeforeDelivery),
            'deliveryCost' => $this->round($deliveryCost),
            'discountValue' => $this->round($discountValue),
            'totalExclVat' => $this->round($totalExclVat),
            'vatAmount' => $this->round($vatAmount),
            'totalInclVat' => $this->round($totalInclVat),
            'missingInformation' => $missing,
            'canSave' => $lineItems !== [],
            'readyForReview' => $lineItems !== [] && $missing === [],
        ];
    }

    private function deliveryCost(string $delivery, float $subtotal): float
    {
        return match ($delivery) {
            '24h' => 20.00,
            '48h' => 15.00,
            'post' => $subtotal < 50 ? 7.00 : 5.00,
            'pickup' => 0.00,
            default => throw new InvalidArgumentException('Ongeldige levermethode.'),
        };
    }

    private function deliveryLabel(string $delivery): string
    {
        return match ($delivery) {
            '24h' => 'Spoedlevering binnen 24 uur',
            '48h' => 'Spoedlevering binnen 48 uur',
            'post' => 'Verzending per post',
            default => 'Afhaling in Herzele',
        };
    }

    /** @return string[] */
    private function stringList(mixed $value): array
    {
        if (!is_array($value)) {
            return [];
        }

        return array_values(array_filter(array_map(
            static fn (mixed $item): string => is_scalar($item) ? trim((string) $item) : '',
            $value
        )));
    }

    private function nullableString(mixed $value): ?string
    {
        if (!is_scalar($value)) {
            return null;
        }

        $value = trim((string) $value);
        return $value === '' ? null : $value;
    }

    private function nullablePositiveFloat(mixed $value): ?float
    {
        if ($value === null || $value === '' || !is_numeric($value)) {
            return null;
        }

        $number = (float) $value;
        return $number > 0 ? $number : null;
    }

    private function nullablePositiveInt(mixed $value): ?int
    {
        if ($value === null || $value === '' || !is_numeric($value)) {
            return null;
        }

        $number = (int) $value;
        return $number > 0 ? $number : null;
    }

    private function round(float $value): float
    {
        return round($value, 2);
    }
}
