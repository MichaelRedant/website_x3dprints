define(['views/record/panels/bottom'], (BottomPanelView) => {
    return class extends BottomPanelView {
        templateContent = `
            <div class="x3d-ai-quote-assistant">
                <div class="alert alert-info">
                    <strong>Gecontroleerde conceptofferte.</strong>
                    De aanvraagtekst wordt bij <em>Analyseren</em> naar OpenAI gestuurd zonder API-opslag
                    (<code>store: false</code>). Verwijder persoonsgegevens die niet nodig zijn.
                    Bedragen komen uitsluitend uit de vaste X3DPrints-prijsregels en niets wordt automatisch verzonden.
                </div>

                <div class="form-group">
                    <label for="x3d-ai-source-{{cid}}">Aanvraagtekst</label>
                    <textarea id="x3d-ai-source-{{cid}}" class="form-control" data-field="sourceText" rows="8">{{sourceText}}</textarea>
                </div>

                <div class="form-group">
                    <label for="x3d-ai-corrections-{{cid}}">Slicerdata, prijsinstructies en correcties</label>
                    <textarea id="x3d-ai-corrections-{{cid}}" class="form-control" data-field="corrections" rows="6"
                        placeholder="Voorbeeld: PETG 543 g aan 25,99/kg; PLA Wood 95 g aan 27,99/kg; 19,6 uur op 2 kW; 6 printjobs; CAD vaste prijs 100; productie afronden op 105; verzending optioneel 7,50.">{{corrections}}</textarea>
                    <p class="help-block">Expliciete waarden hier hebben voorrang. Onbekende cijfers worden nooit door AI ingevuld.</p>
                </div>

                <div class="btn-group" role="group" aria-label="AI-offerteacties">
                    <button type="button" class="btn btn-primary" data-action="analyze" {{#if busy}}disabled{{/if}}>
                        {{#if busy}}Bezig met analyseren...{{else}}Aanvraag analyseren{{/if}}
                    </button>
                    {{#if quote}}
                    <button type="button" class="btn btn-success" data-action="save" {{#unless quote.canSave}}disabled{{/unless}}>
                        Opslaan als concept
                    </button>
                    {{/if}}
                </div>

                {{#if statusMessage}}
                <div class="alert {{statusClass}}" style="margin-top: 12px;">{{statusMessage}}</div>
                {{/if}}

                {{#if quote}}
                <hr>
                <div class="row">
                    <div class="col-md-8">
                        <h4>{{analysis.quoteTitle}}</h4>
                        <p>{{analysis.requestSummary}}</p>
                    </div>
                    <div class="col-md-4 text-right">
                        <div><strong>{{quote.totalExclVatFormatted}} EUR</strong> basisofferte</div>
                        {{#if quote.hasOptions}}<div>{{quote.totalWithOptionsFormatted}} EUR met alle opties</div>{{/if}}
                        {{#if quote.hasOptionalDelivery}}<div>+ {{quote.optionalDeliveryCostFormatted}} EUR optionele verzending</div>{{/if}}
                        <div class="text-muted small">Btw-vrijstellingsregeling</div>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-striped table-condensed">
                        <thead>
                            <tr>
                                <th>Type</th>
                                <th>Offertepost</th>
                                <th>Aantal</th>
                                <th class="text-right">Eenheidsprijs</th>
                                <th class="text-right">Totaal excl. btw</th>
                            </tr>
                        </thead>
                        <tbody>
                            {{#each quote.lineItems}}
                            <tr>
                                <td>{{pricingRoleLabel}}</td>
                                <td>
                                    <strong>{{description}}</strong>
                                    {{#if details}}<div class="text-muted small">{{details}}</div>{{/if}}
                                </td>
                                <td>{{quantity}}</td>
                                <td class="text-right">{{unitPriceFormatted}} EUR</td>
                                <td class="text-right">{{totalFormatted}} EUR</td>
                            </tr>
                            {{/each}}
                        </tbody>
                    </table>
                </div>

                {{#if quote.missingInformation.length}}
                <div class="alert alert-warning">
                    <strong>Nog te bevestigen voor een definitieve offerte:</strong>
                    <ul>
                        {{#each quote.missingInformation}}<li>{{this}}</li>{{/each}}
                    </ul>
                </div>
                {{else}}
                <div class="alert alert-success">
                    Alle vereiste prijsgegevens zijn aanwezig. Controleer de berekening en tekst voor verzending.
                </div>
                {{/if}}

                <div class="form-group">
                    <label for="x3d-ai-internal-text-{{cid}}">Interne berekening en commerciële controle</label>
                    <textarea id="x3d-ai-internal-text-{{cid}}" class="form-control" data-field="internalText" rows="16">{{quote.internalText}}</textarea>
                    <p class="help-block">Ruwe materiaal-, stroom- en dryingberekening. Deze tekst is niet voor de klant.</p>
                </div>

                <div class="form-group">
                    <label for="x3d-ai-customer-subject-{{cid}}">Onderwerp klantmail ({{quote.customerLanguageLabel}})</label>
                    <input id="x3d-ai-customer-subject-{{cid}}" class="form-control" data-field="customerSubject" value="{{quote.customerSubject}}">
                </div>

                <div class="form-group">
                    <label for="x3d-ai-customer-text-{{cid}}">Klantklare e-mail</label>
                    <textarea id="x3d-ai-customer-text-{{cid}}" class="form-control" data-field="customerText" rows="20">{{quote.customerText}}</textarea>
                    <p class="help-block">De taal volgt de klantaanvraag. Bedragen komen uitsluitend uit de berekening hierboven.</p>
                    <button type="button" class="btn btn-default" data-action="copyCustomerMail">Kopieer klantmail</button>
                </div>
                {{/if}}

                {{#if savedRecord}}
                <div class="alert alert-success">
                    Concept opgeslagen: <a href="#X3dAiQuote/view/{{savedRecord.id}}">{{savedRecord.name}}</a>.
                    Er is geen e-mail verstuurd.
                </div>
                {{/if}}
            </div>
        `

        events = {
            'click [data-action="analyze"]': 'actionAnalyze',
            'click [data-action="save"]': 'actionSave',
            'input [data-field="sourceText"]': 'captureSourceText',
            'input [data-field="corrections"]': 'captureCorrections',
            'input [data-field="internalText"]': 'captureInternalText',
            'input [data-field="customerSubject"]': 'captureCustomerSubject',
            'input [data-field="customerText"]': 'captureCustomerText',
            'click [data-action="copyCustomerMail"]': 'actionCopyCustomerMail',
        }

        setup() {
            super.setup();

            this.scope = this.model.entityType || this.model.name || 'Lead';
            this.sourceText = this.buildInitialSourceText();
            this.corrections = '';
            this.result = null;
            this.savedRecord = null;
            this.busy = false;
            this.statusMessage = '';
            this.statusClass = 'alert-info';
        }

        data() {
            const analysis = this.result ? this.result.analysis : null;
            const quote = this.result ? this.prepareQuote(this.result.quote) : null;

            return {
                cid: this.cid,
                sourceText: this.sourceText,
                corrections: this.corrections,
                analysis,
                quote,
                busy: this.busy,
                statusMessage: this.statusMessage,
                statusClass: this.statusClass,
                savedRecord: this.savedRecord,
            };
        }

        buildInitialSourceText() {
            const parts = [];
            const recordName = this.model.get('name');
            const description = this.model.get('description');
            const importSummary = this.model.get('summary');
            const parsedPayload = this.model.get('parsedPayload');

            if (recordName) {
                parts.push(`Onderwerp: ${recordName}`);
            }
            if (description) {
                parts.push(`Aanvraag:\n${description}`);
            }
            if (importSummary) {
                parts.push(`X3DImport-samenvatting:\n${importSummary}`);
            }
            if (parsedPayload) {
                parts.push(`X3DImport-data:\n${parsedPayload}`);
            }

            return parts.join('\n\n');
        }

        captureSourceText(event) {
            this.sourceText = event.currentTarget.value;
        }

        captureCorrections(event) {
            this.corrections = event.currentTarget.value;
        }

        captureCustomerText(event) {
            if (this.result) {
                this.result.quote.customerText = event.currentTarget.value;
            }
        }

        captureInternalText(event) {
            if (this.result) {
                this.result.quote.internalText = event.currentTarget.value;
            }
        }

        captureCustomerSubject(event) {
            if (this.result) {
                this.result.quote.customerSubject = event.currentTarget.value;
            }
        }

        async actionAnalyze() {
            this.captureCurrentValues();
            this.busy = true;
            this.savedRecord = null;
            this.statusMessage = 'De aanvraag wordt gestructureerd en daarna met vaste prijsregels berekend.';
            this.statusClass = 'alert-info';
            await this.reRender();

            try {
                this.result = await Espo.Ajax.postRequest('X3dAiQuote/analyze', {
                    sourceText: this.sourceText,
                    corrections: this.corrections,
                    sourceRecordType: this.scope,
                    sourceRecordId: this.model.id,
                }, {timeout: 120000});
                this.statusMessage = this.result.quote.readyForReview
                    ? 'Analyse gereed. Controleer prijsregels en klanttekst.'
                    : 'Concept gemaakt. Vul de gemarkeerde gegevens aan en analyseer opnieuw.';
                this.statusClass = this.result.quote.readyForReview ? 'alert-success' : 'alert-warning';
            } catch (xhr) {
                this.statusMessage = this.readError(xhr);
                this.statusClass = 'alert-danger';
            } finally {
                this.busy = false;
                await this.reRender();
            }
        }

        async actionSave() {
            if (!this.result || !this.result.quote.canSave) {
                return;
            }

            this.captureCurrentValues();
            this.busy = true;
            this.statusMessage = 'Concept wordt gekoppeld aan dit CRM-record.';
            this.statusClass = 'alert-info';
            await this.reRender();

            try {
                const payload = this.buildSavePayload();
                const record = await Espo.Ajax.postRequest('X3dAiQuote', payload);
                this.savedRecord = {id: record.id, name: record.name || payload.name};
                this.statusMessage = 'Offerteconcept opgeslagen. Er is niets naar de klant verzonden.';
                this.statusClass = 'alert-success';
            } catch (xhr) {
                this.statusMessage = this.readError(xhr);
                this.statusClass = 'alert-danger';
            } finally {
                this.busy = false;
                await this.reRender();
            }
        }

        captureCurrentValues() {
            const source = this.$el.find('[data-field="sourceText"]');
            const corrections = this.$el.find('[data-field="corrections"]');
            const customerText = this.$el.find('[data-field="customerText"]');
            const internalText = this.$el.find('[data-field="internalText"]');
            const customerSubject = this.$el.find('[data-field="customerSubject"]');

            if (source.length) this.sourceText = source.val();
            if (corrections.length) this.corrections = corrections.val();
            if (customerText.length && this.result) this.result.quote.customerText = customerText.val();
            if (internalText.length && this.result) this.result.quote.internalText = internalText.val();
            if (customerSubject.length && this.result) this.result.quote.customerSubject = customerSubject.val();
        }

        buildSavePayload() {
            const {analysis, quote, ai} = this.result;
            const validUntil = new Date();
            validUntil.setDate(validUntil.getDate() + 30);

            const payload = {
                name: analysis.quoteTitle || `Conceptofferte ${this.model.get('name') || ''}`.trim(),
                status: 'Draft',
                sourceRecordType: this.scope,
                sourceRecordId: this.model.id,
                sourceRecordName: this.model.get('name') || '',
                sourceType: this.scope === 'X3dImport' ? 'X3DImport' : analysis.sourceType,
                requestSummary: analysis.requestSummary,
                customerLanguage: quote.customerLanguage,
                customerSubject: quote.customerSubject,
                sourceText: this.sourceText,
                internalText: quote.internalText,
                lineItemsText: JSON.stringify(quote.lineItems, null, 2),
                assumptions: (analysis.assumptions || []).join('\n'),
                missingInformation: (quote.missingInformation || []).join('\n'),
                customerText: quote.customerText,
                currency: quote.currency,
                totalExclVat: quote.totalExclVat,
                optionsTotal: quote.optionsTotal,
                totalWithOptions: quote.totalWithOptions,
                vatRate: quote.vatRate,
                vatAmount: quote.vatAmount,
                totalInclVat: quote.totalInclVat,
                vatStatement: quote.vatStatement,
                validUntil: validUntil.toISOString().slice(0, 10),
                priceRulesVersion: quote.rulesVersion,
                aiModel: ai.model,
                aiResponseId: ai.responseId,
                promptVersion: ai.promptVersion,
            };

            if (this.scope === 'Lead') {
                payload.leadId = this.model.id;
                payload.leadName = this.model.get('name') || '';
            }
            if (this.scope === 'Opportunity') {
                payload.opportunityId = this.model.id;
                payload.opportunityName = this.model.get('name') || '';
            }
            if (this.scope === 'X3dImport') {
                payload.x3dImportId = this.model.id;
                payload.x3dImportName = this.model.get('name') || '';
            }

            const assignedUserId = this.model.get('assignedUserId');
            if (assignedUserId) {
                payload.assignedUserId = assignedUserId;
                payload.assignedUserName = this.model.get('assignedUserName') || '';
            }

            return payload;
        }

        prepareQuote(quote) {
            const languageName = {nl: 'Nederlands', fr: 'Frans', en: 'Engels', de: 'Duits'};

            return {
                ...quote,
                totalExclVatFormatted: this.formatMoney(quote.totalExclVat),
                totalInclVatFormatted: this.formatMoney(quote.totalInclVat),
                totalWithOptionsFormatted: this.formatMoney(quote.totalWithOptions),
                optionalDeliveryCostFormatted: this.formatMoney(quote.optionalDeliveryCost),
                hasOptions: Number(quote.optionsTotal || 0) > 0,
                hasOptionalDelivery: Number(quote.optionalDeliveryCost || 0) > 0,
                customerLanguageLabel: languageName[quote.customerLanguage] || quote.customerLanguage,
                lineItems: (quote.lineItems || []).map(item => ({
                    ...item,
                    pricingRoleLabel: item.pricingRole === 'option'
                        ? 'Optie'
                        : item.pricingRole === 'alternative' ? 'Alternatief'
                        : item.pricingRole === 'delivery-option' ? 'Verzending' : 'Basis',
                    unitPriceFormatted: this.formatMoney(item.unitPrice),
                    totalFormatted: this.formatMoney(item.total),
                })),
            };
        }

        async actionCopyCustomerMail() {
            this.captureCurrentValues();
            if (!this.result) return;

            const text = `Onderwerp: ${this.result.quote.customerSubject}\n\n${this.result.quote.customerText}`;
            try {
                await navigator.clipboard.writeText(text);
                this.statusMessage = 'Klantmail gekopieerd. Controleer hem voor verzending.';
                this.statusClass = 'alert-success';
            } catch (error) {
                this.statusMessage = 'Kopiëren werd door de browser geblokkeerd. Selecteer de klantmail handmatig.';
                this.statusClass = 'alert-warning';
            }
            await this.reRender();
        }

        formatMoney(value) {
            return Number(value || 0).toLocaleString('nl-BE', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
            });
        }

        readError(xhr) {
            return xhr && xhr.responseJSON && xhr.responseJSON.message
                ? xhr.responseJSON.message
                : 'De actie is mislukt. Controleer de serverconfiguratie en probeer opnieuw.';
        }
    }
});
